Step 1: Download si2443_Lab2.zip and unzip it using the following command:
```
unzip si2443_Lab2.zip
```
Step 2: Install the required dependencies : 

```
pip3 install -r requirements.txt
```

Step 3: To see the output of the C2 to C5, Q3, Q4 codes run the following command :

```
python3 lab2.py
```

Step 4: To see the output of the Extra Credit codes, run the following command :

```
python3 ExtraCredit.py
```
Additionally, to see the plots for C3, run the following command :
```
python3 plots.py
```
To see the plots for Extra Credit C3, run the following command :
```
python3 Extraplots.py
```
